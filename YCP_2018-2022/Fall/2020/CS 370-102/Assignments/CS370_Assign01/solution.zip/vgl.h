#ifndef __VGL_H__
#define __VGL_H__

#include "include/GLEW/glew.h"

#include "include/GLFW/glfw3.h"

#define BUFFER_OFFSET(x)  ((const void*) (x))
#endif /* __VGL_H__ */
